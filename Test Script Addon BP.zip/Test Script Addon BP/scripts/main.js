import { world, system, } from "@minecraft/server"


world.afterEvents.playerJoin.subscribe(event => {
    system.runTimeout(() => {

        world.sendMessage(event.playerName);
        world.getPlayers({
            name: event.playerName
        })[0].playSound("random.anvil_use")

    }, 250)
})

world.beforeEvents.itemUse.subscribe(event => {
	system.run(() => {
    event
        .source
        .getBlockFromViewDirection()
        .block
        .setType("minecraft:stone")
    })
})